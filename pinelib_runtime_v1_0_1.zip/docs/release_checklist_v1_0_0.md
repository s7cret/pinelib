# Release Checklist v1.0.0

- [x] Version bumped to `1.0.0` in `pyproject.toml` and `pinelib/version.py`.
- [x] Tests updated for v1.0.0 package version expectations.
- [x] README updated for stable v1.0.0 framing.
- [x] Public API review updated.
- [x] Coverage/limitations map updated.
- [x] Migration guide from v0.9.0 added.
- [x] Release notes and changelog added.
- [x] Final audit added.
- [x] Full release gates run: compileall, pytest, mypy, release builder, manifest/archive validation.
- [x] Archive and manifest generated: `pinelib_runtime_v1_0_0.zip`, `RELEASE_MANIFEST_v1_0_0.json`.
- [x] Commit created: `Release pinelib runtime v1.0.0`.
