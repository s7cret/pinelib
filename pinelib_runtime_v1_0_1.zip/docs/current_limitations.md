# Current Limitations

Current release: v1.0.1 (`runtime_contract_v1.4` / `TZ_01`). See `docs/coverage_map_v1_0_1.md` for the full map.

- No fake TradingView parity. Missing features must stay explicit via diagnostics/errors.
- Supplied realtime tick execution is supported locally; full TradingView realtime lifecycle parity is not claimed. The TradingView supplied-tick oracle case is platform-blocked because TV exposes no deterministic tick-stream export/injection path, and historical bars without ticks emit an explicit `calc_on_every_tick` fallback diagnostic.
- Strategy tester parity is partial: no margin calls/liquidation model, incomplete full realtime lifecycle, and `backtest_fill_limits_assumption` is explicitly unsupported and does not affect fills.
- Bar Magnifier requires valid lower-timeframe data fully inside the chart-bar interval; invalid/missing data warns/falls back or errors in strict mode.
- `request.security` / `request.security_lower_tf` nested requests are unsupported unless config explicitly enables them.
- `request.security_lower_tf` is deterministic first-slice support only. `data_provider` applies `calc_bars_count` as a conservative global cap through the active chart bar; `intrabar_provider` remains chart-bar scoped and records this limitation in query metadata.
- Visual support is a deterministic lifecycle event recorder, not a renderer.
- Reference-type history access is unsupported; `TypeInfo.is_history_allowed=False` is enforced for all series.
- TA overload matrix is incomplete; stateful runtime helpers require stable explicit `state_id`.
- IO helpers cover local CSV and optional Parquet only.

- `time()` / `time_close()` with non-chart timeframes are unsupported and raise `PL_UNSUPPORTED_TIMEFRAME_TIMEFUNC`; chart timeframe and `None` preserve current behavior.
- `request.security` precomputed `Sequence` expressions are retained as a test/backcompat helper; generated-code contract path is callable child-runtime evaluation.
- TradingView oracle suite has zero pending cases: exportable cases are verified under `fixtures/tradingview/`, while `calc_on_every_tick_supplied_ticks` is explicitly `platform_blocked` and not parity coverage.
