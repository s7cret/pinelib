# Visual coverage matrix v1.0.1

PineLib visual support is a deterministic recorder for generated-code side effects. It is not a TradingView renderer.

| Area | Status | Notes |
|---|---|---|
| Object ids | Supported foundation | Stable `PineObjectId` lifecycle ids for recorder consumers. |
| `label` lifecycle | Recorder-supported | `new`, `set`, `delete`, and max-count enforcement. Rendering/layout parity pending. |
| `line` lifecycle | Recorder-supported | Event capture and max-count enforcement. Pixel/render semantics pending. |
| `box` lifecycle | Recorder-supported | Event capture and max-count enforcement. Render semantics pending. |
| Tables | Not renderer-verified | Must remain explicit future work before parity claims. |
| Namespaces | Partial | Recorder namespace exists; full Pine visual namespace and overload matrix pending. |
| Replay/render output | Unsupported | Downstream adapters may consume events; PineLib does not claim chart visual parity. |
