# PineLib Runtime v1.0.1 Coverage and Limitations Map

Built against `runtime_contract_v1.4` / `TZ_01`.

## Covered with tests in v1.0.1

- Bar validation and UTC millisecond timestamps.
- Series current/committed history model, including runtime enforcement of `TypeInfo.is_history_allowed` and explicit reference-history rejection.
- Runtime bar loop, built-in OHLCV series, diagnostics, inputs, `barstate.islastconfirmedhistory`, symbol/timeframe info, and child request namespace metadata.
- Sessions/timezones: IANA zones, regular and overnight sessions, DST behavior, calendar helpers, and explicit unsupported errors for non-chart `time()` / `time_close()` timeframe aggregation.
- `request.security` foundation: callable child runtime path, gaps/lookahead merge modes, missing symbol handling, nested request diagnostics. Precomputed `Sequence` expressions remain a test/backcompat helper, not the generated-code contract path.
- Strategy broker MVP: market/limit/stop/stop-limit orders, next-bar vs close processing, reversal, pyramiding, exit reservations, OCA reduce, commission/slippage/sizing, Bar Magnifier provenance, invalid intrabar fallback/error handling, guarded `calc_on_order_fills`, and realtime tick execution when explicit ticks are supplied.
- `calc_on_every_tick=True` now warns only for historical bars without explicit realtime ticks; supplied ticks run per-tick without false fallback diagnostics.
- `backtest_fill_limits_assumption` is consistently unsupported in v1.0.1: it emits/raises via strategy setting diagnostics and does not alter fills.
- Backtest runner/report snapshots and golden/strategy compare helpers.
- TradingView-export fixture loaders plus an oracle fixture directory/runner with seven TradingView oracle-verified cases and one separately counted platform-blocked supplied-tick oracle case.
- Visual/reference foundations: deterministic visual event recorder, object limits, array/map/matrix shallow-copy semantics, unsupported reference history diagnostic.
- TA namespace: tested batch/runtime core helpers plus extended helper set; runtime stateful helpers require explicit stable `state_id`.

## Explicit limitations / unsupported matrix

- No full TradingView parity claim: `calc_on_every_tick` supplied-tick parity is platform-blocked because TradingView does not expose a deterministic tick-stream oracle/export for injected or refreshed realtime ticks.
- `time()` / `time_close()` with a non-chart timeframe is unsupported and raises `PL_UNSUPPORTED_TIMEFRAME_TIMEFUNC` after recording a diagnostic.
- `backtest_fill_limits_assumption` is unsupported and ignored for fills after diagnostic/error policy handling.
- Margin calls/liquidation model remains diagnostic-only.
- Full TradingView realtime lifecycle parity is not claimed; deterministic supplied `TickUpdate` streams are supported locally, while TradingView supplied-tick oracle verification is platform-blocked.
- Bar Magnifier requires valid lower-timeframe bars fully inside the chart-bar interval; invalid/missing data warns/falls back or errors in strict mode.
- Nested `request.*` calls are unsupported unless config explicitly enables them.
- `request.security_lower_tf` is deterministic first-slice support only; realtime partial intrabars and remote feed lifecycle accounting are pending.
- Visual API is a lifecycle event recorder, not a TradingView renderer.
- Reference-type history is unsupported.
- TA overload matrix is incomplete; unsupported runtime overloads must fail explicitly rather than approximate silently.
- IO helpers target local CSV and optional Parquet only.

## TradingView oracle status

See `fixtures/tradingview/README.md` and `fixtures/tradingview/cases.json`. Final suite status has zero `pending_external_oracle` cases: exportable cases are `oracle_verified`; `calc_on_every_tick_supplied_ticks` is `platform_blocked` with evidence and is not counted as parity coverage.
