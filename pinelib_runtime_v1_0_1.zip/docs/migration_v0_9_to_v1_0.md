# Migration Guide: v0.9.0 to v1.0.0

v1.0.0 is a stabilization release. v0.9 generated-code consumers should work unchanged.

## Required actions

1. Update package/version expectations from `0.9.0` to `1.0.0`.
2. Keep imports constrained to `pinelib.__all__` and documented namespace modules.
3. Review `docs/current_limitations.md` and `docs/coverage_map_v1_0_0.md` before asserting parity.
4. Regenerate release artifacts with `python scripts/build_release.py` if local files change.

## No fake parity

If a TradingView feature is missing, keep it as explicit diagnostic/error behavior. Do not approximate silently in generated adapters.

## Breaking changes

None intentionally introduced for v0.9 public API consumers.
