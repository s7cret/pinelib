# Iteration D — deterministic realtime and broker sequencing

This iteration adds a bounded runtime foundation for TradingView-like strategy scheduling without claiming oracle parity.

Implemented semantics:

- `TickUpdate` + `PineRuntime.begin_realtime_bar()` / `update_realtime_tick()` model explicit caller-supplied realtime updates. PineLib never synthesizes ticks from OHLC.
- `run_generated_strategy(..., realtime_ticks=...)` executes `calc_on_every_tick=True` strategies once per supplied tick; the final tick is confirmed deterministically.
- `StrategyContext` mirrors `process_orders_on_close`, `calc_on_order_fills`, and `calc_on_every_tick` into `RuntimeConfig` and fails closed on conflicts.
- Historical `calc_on_order_fills` order is explicit: generated pass → broker pass → mark fill pending → update position/equity already done at fill time → generated recalc pass → broker recalc pass, bounded by `max_recalculations_per_bar`.
- Bar Magnifier continues to use caller/provider intrabars when valid and fails closed in strict/error mode; otherwise it emits an explicit fallback diagnostic.
- Margin fields are preserved and margin breaches emit diagnostics. PineLib does not silently emulate TradingView forced liquidation because exact parity is not oracle-verified.
- `fill_orders_on_standard_ohlc` is accepted as declaration data but diagnosed as unsupported.

Remaining limitations:

- No remote TradingView realtime feed lifecycle, session roll-up, or max-intrabars accounting is synthesized.
- Forced liquidation is diagnostic-only.
- Exact TradingView parity requires external oracle fixtures and is not claimed here.
