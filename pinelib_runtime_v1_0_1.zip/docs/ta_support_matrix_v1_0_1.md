# TA support matrix v1.0.1

Runtime stateful TA calls from generated code must use explicit stable `state_id` values. Batch helpers exist for tests/data work but do not by themselves prove generated-code parity.

| Function group | Runtime status | Batch status | Notes |
|---|---|---|---|
| `sma`, `ema`, `rma` | Supported core | Supported | Covered by unit tests; stateful runtime path requires `runtime` + `state_id` where applicable. |
| `tr`, `atr`, `rsi`, `macd` | Supported core | Supported | Runtime state is deterministic but still needs TradingView oracle fixtures for parity claims. |
| `highest`, `lowest`, `change`, crosses | Supported foundation | Supported | Source-compatible overload expansion pending. |
| Extended statistical helpers | Partial | Mostly batch-first | Treat unsupported runtime overloads as explicit errors; expand only with fixtures. |
| `dmi`, `vwap`, `hma` and advanced overloads | Incomplete / batch-only in places | Partial | No silent generated-code parity claim until runtime overloads and oracle exports exist. |
