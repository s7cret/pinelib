# PineLib Runtime v1.0.0 Public API Review

v1.0.0 stabilizes the import surface introduced and reviewed during v0.9. The supported public API is the `pinelib.__all__` export list plus documented namespace modules (`pinelib.ta`, `pinelib.math`, `pinelib.string`, `pinelib.color`). Anything below private modules or with a leading underscore is internal.

## Stable public areas

- Core runtime: `Bar`, `Series`, `PineRuntime`, `RuntimeConfig`, symbol/timeframe metadata, Pine NA/operator helpers.
- Requests/data: provider protocols, in-memory provider, `security`, `security_lower_tf`, deterministic series merge helpers, and provider/lower-timeframe query metadata records.
- Strategy/backtest: `StrategyContext`, order/fill/trade objects, generated-strategy runner, reports, snapshots, and compare helpers.
- IO/parity harnesses: local bar loaders, TradingView CSV fixture loaders, strategy/indicator compare reports. These are harnesses, not claims of complete TradingView parity.
- Visual/reference foundations: deterministic visual event recorder and reference containers.
- Namespaces: tested TA/math/string/color helper subsets.

## Compatibility policy

- Removing or renaming an item in `pinelib.__all__` is a breaking change.
- Changing documented semantics for stable public functions is a breaking change unless the old behavior was a bug that contradicted the runtime contract.
- Adding new public helpers is allowed in minor releases when they do not weaken explicit diagnostics for unsupported behavior.
- Unsupported TradingView behavior must remain explicit; silent approximation is not acceptable compatibility.
