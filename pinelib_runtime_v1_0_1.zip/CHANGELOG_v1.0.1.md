# PineLib v1.0.1

Integrity + runtime parity hardening patch.

- Added release integrity gate validating manifest archive SHA and git commit provenance.
- Added Broker v2 acceptance coverage for trailing stop ratchets, limit-fill assumptions, OCA reduce mutation, margin/liquidation diagnostics, lower-timeframe request diagnostics, nested request diagnostics, and visual declaration count wiring.
- Implemented deterministic trailing stop activation/ratchet support for `strategy.exit` when `trail_offset` plus `trail_price` or `trail_points` is provided.
- Implemented `backtest_fill_limits_assumption` limit-order penetration checks using `syminfo.mintick`.
- Added explicit unsupported contract for `request.security_lower_tf`.
- Kept TradingView parity claims limited to fixture-backed local semantics; forced margin liquidation and realtime tick parity remain documented diagnostics, not claimed full parity.
