# Release Notes: PineLib Runtime v1.0.0

PineLib Runtime v1.0.0 is the first stable release for `runtime_contract_v1.4` / `TZ_01`.

This release finalizes the v0.9 hardening work: stable version metadata, reviewed public imports, typed package marker, release documentation, reproducible archive/manifest generation, and explicit limitation language.

## What is stable

- Top-level public import surface documented by `pinelib.__all__`.
- Core runtime/bar/series/input/time/session/request-security foundations.
- StrategyContext broker-emulator MVP and generated-strategy runner for supported historical-bar workflows.
- JSON-safe backtest reports, snapshots, compare helpers, fixture loaders, and local bar IO.
- Tested namespace helpers for TA/math/string/color foundations.

## What is not claimed

v1.0.0 does **not** claim complete TradingView parity. Missing or unsupported parity-affecting behavior must remain explicit through diagnostics/errors rather than silent approximation.

See `docs/current_limitations.md` and `docs/coverage_map_v1_0_0.md` before treating any strategy result as production parity evidence.

## Artifacts

- Archive: `pinelib_runtime_v1_0_0.zip`
- Manifest: `RELEASE_MANIFEST_v1_0_0.json`
