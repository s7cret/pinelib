# FINAL AUDIT v1.0.1

Date: 2026-04-27
Contract: `runtime_contract_v1.4`

Verdict: v1.0.1 is a parity-oriented runtime foundation with P0/P1 tail fixes applied. It is **not** a full TradingView clone; exportable oracle cases are TradingView-backed, and the supplied-tick oracle is explicitly platform-blocked rather than pending.

## Closed in v1.0.1

- Bar Magnifier intrabar validation now rejects intrabars opening before the chart bar, closing after the chart bar, or arriving in non-monotonic open/close order.
- `time()` / `time_close()` no longer silently ignore non-chart timeframes; unsupported requests raise `PL_UNSUPPORTED_TIMEFRAME_TIMEFUNC` with diagnostics.
- `calc_on_every_tick` fallback warnings moved from attach-time to execution-time; explicit realtime ticks do not emit false fallback warnings.
- `backtest_fill_limits_assumption` is consistently unsupported and no longer changes limit fills through hidden partial behavior.
- `TypeInfo.is_history_allowed` is enforced by `Series.__getitem__`.
- `barstate.islastconfirmedhistory` is exposed and set by the backtest runner for historical-only and historical-before-realtime schedules.
- Child request runtimes retain `request_namespace` for traceability.
- Release docs now point to v1.0.1 coverage/limitations.

## Remaining explicit limitations

See `docs/coverage_map_v1_0_1.md` for the current unsupported matrix. Most importantly, non-chart timeframe aggregation in `time()`/`time_close()`, `backtest_fill_limits_assumption`, full margin/liquidation, full realtime lifecycle parity, renderer-level visuals, reference history, and portions of the TA overload matrix remain unsupported.

## Oracle status

Oracle harness exists under `fixtures/tradingview/` and `scripts/run_tv_golden_suite.py`. Final suite status has zero `pending_external_oracle` cases: seven cases are `oracle_verified`; `calc_on_every_tick_supplied_ticks` is `platform_blocked` with documentation/CDP evidence because TradingView exposes no deterministic supplied-tick stream export or injection oracle. No full parity claim is made for that blocked case.
