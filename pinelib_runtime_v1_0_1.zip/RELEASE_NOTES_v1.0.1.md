# Release notes: PineLib runtime v1.0.1

Patch release focused on fixing v1.0 release provenance and adding runtime-parity hardening tests/diagnostics.

## Integrity

The release builder now emits `RELEASE_MANIFEST_v1_0_1.json` for the current package version and CI runs `scripts/check_release_integrity.py` to verify archive SHA and manifest commit provenance.

## Runtime hardening

Implemented or explicitly diagnosed:

- trailing stop activation/ratchet behavior for supported `strategy.exit` argument combinations;
- `backtest_fill_limits_assumption` price-improvement checks;
- OCA reduce quantity mutation;
- margin/liquidation risk diagnostics without false forced-liquidation parity claims;
- `request.security_lower_tf` explicit unsupported diagnostics;
- nested `request.security` explicit unsupported diagnostics;
- strategy visual max-count declarations wired into `VisualRecorder`.

## Known deferred blockers

- Full TradingView broker parity matrix is not claimed.
- Forced margin liquidation is diagnostic-only.
- Realtime/tick execution and `calc_on_every_tick` remain diagnostic/fallback paths unless real intrabar/realtime data is supplied.
- Full lower-timeframe array lifecycle for `request.security_lower_tf` remains unsupported.
