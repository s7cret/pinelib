# TradingView oracle fixtures

This directory stores TradingView-derived golden fixtures and evidence for cases where TradingView exposes an exportable oracle. It also records platform-blocked cases separately so the suite has no ambiguous pending bucket.

Status definitions:

- `oracle_verified`: bars and expected outputs came from a TradingView export/capture and may be used as parity evidence.
- `golden_synthetic`: local deterministic fixture useful for harness testing, not TradingView parity evidence.
- `platform_blocked`: a required parity question was attempted, but TradingView does not expose the oracle needed to verify it honestly. These cases must include evidence, must not include fabricated required outputs, and must not be described as TradingView parity coverage.

Current status: `cases.json` contains no `pending_external_oracle` cases. `calc_on_every_tick_supplied_ticks` is `platform_blocked` because TradingView documents `calc_on_every_tick` as realtime-update behavior, loses tick data on refresh, and exposes no UI/API/CDP path to inject or export the deterministic supplied tick stream required for `ticks.csv` and `expected_report.json`.
