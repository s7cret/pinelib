# calc_on_every_tick supplied-ticks oracle closure

Status: `platform_blocked` / oracle not applicable.

This case asks for a TradingView-derived oracle for PineLib's explicit supplied `TickUpdate` stream. That would require TradingView to either accept the same synthetic ticks or export the exact realtime tick updates used by a `calc_on_every_tick=true` strategy.

## Last oracle attempt evidence

- TradingView Help Center, Strategy properties, Recalculate / `calc_on_every_tick`: TradingView states that this option calculates on each update of realtime bars, that tick data is lost when the chart is refreshed, that it does not affect historical bars, and that historical bars contain no tick data.
- TradingView Pine execution model: scripts execute over historical bars and realtime ticks, but strategy scripts execute once per bar by default; `calc_on_every_tick` changes realtime-bar execution behavior.
- TradingView bar states documentation: indicators/libraries run on all realtime price/volume updates; strategies without `calc_on_every_tick` only run when the realtime bar closes.
- Committed Chromium/CDP capture `fixtures/tradingview/tv_oracle_capture_2026-04-27.json` contains top-level `main_bars`, `study_plots`, `visible_range_inputs`, and `sources`; it contains no deterministic tick stream field or supplied-tick export.
- Strategy Tester `reportData` captures used by other oracle-verified cases contain trades/fill reports, not the realtime tick sequence needed to construct `ticks.csv` for this case.

## Closure decision

No fake oracle is acceptable here. Because the platform does not expose a deterministic supplied tick stream, this case is not pending work in PineLib. It is a documented platform limitation and is counted separately from `oracle_verified` cases.

Required files intentionally absent:

- `bars.csv`
- `ticks.csv`
- `expected_report.json`

If TradingView later exposes an official tick export/replay API or a CDP payload with exact realtime updates, this case can be reopened and moved to `oracle_verified` only after those files are committed as TradingView-derived evidence.
