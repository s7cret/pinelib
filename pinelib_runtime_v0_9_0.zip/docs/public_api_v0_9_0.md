# PineLib Runtime v0.9.0 Public API Review

v0.9.0 freezes the intended import surface ahead of 1.0. The supported public API is the `pinelib.__all__` export list plus documented namespace modules (`pinelib.ta`, `pinelib.math`, `pinelib.string`, `pinelib.color`). Anything below private modules or with a leading underscore is internal.

## Stable top-level areas

- Core runtime: `Bar`, `Series`, `PineRuntime`, `RuntimeConfig`, `SymbolInfo`, `TimeframeInfo`, `BarStateInfo`, `InputRegistry`, `InputMetadata`.
- NA/operators/math: `na`, `is_na`, `nz`, `fixnan`, `pine_*` operators, `pine_abs`, `pine_min`, `pine_max`, `pine_round`, `pine_sum`.
- Data/request: `DataProvider`, `IntrabarDataProvider`, `ProviderQueryMetadata`, `InMemoryDataProvider`, `security`, `merge_requested_series_to_chart_bars`.
- Strategy/backtest: `StrategyContext`, `StrategyDeclaration`, `Order`, `Fill`, `Trade`, `StrategySchedule`, `run_generated_strategy`, report/snapshot/compare helpers.
- Parity fixtures: TradingView CSV fixture loaders and compare reports. These are harnesses, not claims of complete TradingView parity.
- Reference/visual containers: `PineArray`, `PineMap`, `PineMatrix`, `reference_history`, `VisualRecorder`, `VisualEvent`, `PineObjectId`.
- Errors and diagnostic codes exported from `pinelib.errors`.

## Internal / not guaranteed

- Concrete state dataclasses inside TA helpers, broker private methods, and runtime storage dictionaries.
- Exact diagnostics payload shape beyond `code` and human-readable `message` unless documented in tests.
- Performance characteristics beyond the smoke benchmarks; correctness and explicit unsupported-feature errors take precedence.

## Compatibility target

0.9.x should avoid renaming or removing top-level exports. Additions are allowed when covered by tests and docs. Breaking changes before 1.0 require a changelog entry and migration note.
