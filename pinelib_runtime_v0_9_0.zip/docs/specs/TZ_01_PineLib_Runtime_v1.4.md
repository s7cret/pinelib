# Техническое задание №1 — PineLib / PainLib Runtime

**Версия ТЗ:** 1.4 consolidated + execution/session/type-contract patch  
**Дата:** 2026-04-27  
**Проект:** PineLib Runtime  
**Альтернативное имя из запроса:** PainLib  
**Рекомендуемое итоговое имя пакета:** `pinelib`  
**Связанные проекты:** Pine2AST, AST2Python, bar-by-bar backtest engine, optimizer  
**Главная цель:** реализовать Python-runtime, максимально совместимый с Pine Script™ v6, чтобы Python-код, сгенерированный AST2Python, давал совпадающие с TradingView результаты на уровне индикаторов, сигналов, сделок и equity curve.


---

## 0. Изменения v1.4 по замечаниям для 1:1 TradingView

Эта версия устраняет неоднозначности, которые реально влияют на совпадение с TradingView. Нормативный приоритет документов:

1. `runtime_contract.md` — общий контракт между PineLib и AST2Python. Если есть противоречие с текстом отдельных ТЗ, контракт главнее.
2. `TZ_01_PineLib_PainLib_Runtime_v1.4.md` — runtime, series, TA, request, strategy/broker.
3. `TZ_02_AST2Python_v1.4.md` — кодогенерация, source map, state_id, diagnostics.

Принятые обязательные решения:

| ID | Решение | Приоритет | Причина для 1:1 |
|---|---|---:|---|
| C-001 | Формализован runtime contract: `PineRuntime`, `Series`, `state_id`, `DataProvider`, `StrategyContext` | P0 | без него AST2Python и PineLib будут по-разному понимать stateful-вызовы |
| C-002 | Зафиксирован формат входных баров CSV/Parquet и timezone UTC/Unix ms | P0 | несовпадение `time`, `time_close`, timezone ломает `request.security`, сессии и сделки |
| C-003 | `commit_current()` вызывает только runtime в `end_bar()` | P0 | иначе `x[1]` может ссылаться на значение текущего бара |
| C-004 | `request.security()` принимает `expression_callable(request_runtime)` и вычисляет expression в requested-context | P0 | иначе HTF/LTF выражение будет считаться на chart timeframe |
| C-005 | `ta.supertrend()` direction фиксируется по TradingView-конвенции: `-1` = bullish/uptrend, `+1` = bearish/downtrend | P1 | знак часто перепутан в сторонних реализациях и ломает сигналы |
| C-006 | `ta.stoch()` возвращает fast %K без скрытого сглаживания | P1 | автоматическое SMA(3) создаёт не-TV значения |
| C-007 | Broker OHLC path фиксируется по правилам TradingView: open→high→low→close если open ближе к high, иначе open→low→high→close | P1 | напрямую влияет на stop/limit fills |
| C-008 | `strategy.exit()` реализует default OCA reduce/reservation semantics | P1 | multi-TP/SL иначе даст другие сделки |
| C-009 | Добавлен `pine_range()` с inclusive end | P2 | нужно для корректной трансляции `for i = a to b` |
| C-010 | Nested `request.security` на MVP явно unsupported с diagnostic, не silently wrong | P2 | лучше упасть явно, чем дать неверный backtest |
| C-011 | Формализован `StrategyExecutionSchedule`: порядок begin_bar → generated code → broker fills → optional recalculation → end_bar | P0 | без него `calc_on_order_fills`, `process_orders_on_close` и strategy-переменные будут расходиться с TradingView |
| C-012 | Добавлен `IntrabarDataProvider` и контракт Bar Magnifier | P0 | `use_bar_magnifier` меняет TP/SL fills и не может быть обычным OHLC-path |
| C-013 | Добавлен session/timezone contract для `time()`, `time_close()`, `input.session`, `syminfo.timezone` | P0 | сессии, overnight и exchange timezone напрямую влияют на сигналы и сделки |
| C-014 | Зафиксирован полный mapping `strategy()` declaration parameters в `StrategyContext` | P0 | молчаливое игнорирование strategy properties даёт другой backtest |
| C-015 | Добавлен Type/Qualifier contract: `const/input/simple/series`, overload validation, bool-v6 restrictions | P1 | неверный qualifier ломает overloads и history/series-семантику |
| C-016 | Добавлена reference semantics для `array/map/matrix/UDT` | P1 | стратегии с pivot/zigzag/UDT иначе расходятся из-за copy/reference поведения |
| C-017 | Расширен input metadata/validation contract | P1 | optimizer и generated params должны использовать те же defaults/options/min/max |
| C-018 | Visual recorder обязан возвращать stable object IDs для `label/line/box/table` | P1 | visual objects могут храниться в `var` и участвовать в side-effect логике |


### 0.1. Дополнения v1.4

Версия v1.4 наследует все решения v1.3 и добавляет недостающие контракты, которые влияют не на стиль реализации, а на совпадение с TradingView: execution schedule, Bar Magnifier, sessions/timezone, full strategy properties, input validation, type/qualifier resolver, reference semantics и visual object IDs.


## 1. Назначение и границы проекта

PineLib — библиотека исполнения Pine Script™ v6-семантики в Python. Она не парсит Pine-код и не генерирует Python-код. Её задача — предоставить runtime-слой, который использует AST2Python-сгенерированный код.

### 1.1. Что PineLib обязана делать

1. Исполнять Pine-подобные time series в bar-by-bar модели.
2. Реализовать `na`, `nz`, `fixnan`, history referencing `x[n]`.
3. Реализовать встроенные функции и пространства имён Pine v6:
   - `ta.*`
   - `math.*`
   - `str.*`
   - `array.*`
   - `matrix.*`
   - `map.*`
   - `request.*`
   - `input.*`
   - `color.*`
   - `syminfo.*`
   - `timeframe.*`
   - `barstate.*`
   - `strategy.*`
4. Предоставить `StrategyContext` и broker-emulator слой, совместимый с базовой логикой TradingView.
5. Поддержать golden-тестирование против выгрузок из TradingView.
6. Работать как зависимость для AST2Python без ручной подгонки под конкретную стратегию.

### 1.2. Что PineLib не обязана делать на первом этапе

1. Не обязана реализовывать визуальные объекты TradingView 1:1:
   - `plot`, `plotshape`, `label`, `line`, `box`, `table`.
   - На первом этапе достаточно no-op/recording API для диагностики.
2. Не обязана подключаться к TradingView API.
3. Не обязана сама скачивать котировки, кроме интерфейсов адаптера данных для `request.security`.
4. Не обязана поддерживать все редкие overload-версии встроенных функций сразу, если они не встречаются в целевых стратегиях.
5. Не обязана оптимизировать всё через numba на MVP-этапе. Сначала точность, потом скорость.

---

## 2. Главные принципы совместимости с Pine v6

### 2.1. Execution model

Pine-код исполняется не как обычный Python-модуль, а последовательно на каждом баре. После обработки закрытого бара значения становятся частью time series и доступны через history reference.

**Требование:** PineLib должна иметь runtime-контекст текущего бара. Все series-значения должны записываться в историю после вычисления бара, а `x[1]` должен возвращать значение с предыдущего бара относительно текущего исполнения.

### 2.2. Time series — не обычный list

Pine series похожи на растущий ряд значений, где:

- `x` или `x[0]` — текущее значение.
- `x[1]` — значение предыдущего бара.
- `x[2]` — значение два бара назад.
- Если истории нет — возвращается `na` для числовых/объектных типов.
- В Pine v6 bool не имеет состояния `na`: отсутствующий bool-history должен давать `False`, если AST2Python знает, что series имеет bool-тип.

### 2.3. `na` и bool в Pine v6

В Pine v6 `bool` не может быть `na`. Поэтому:

- `na(x)`, `nz(x)`, `fixnan(x)` запрещены для bool-типов.
- Для чисел, строк, объектов и ссылочных значений `na` допустим.
- Внутри PineLib необходимо разделять `Series[float]`, `Series[int]`, `Series[bool]`, `Series[color]`, `Series[object]`.

### 2.4. Приоритет — точность, а не скорость

Все индикаторы сначала реализуются в прозрачном Python-коде с тестами. Оптимизация через NumPy/Numba допускается только после появления golden-тестов, доказывающих неизменность результатов.

---

## 3. Архитектура пакета

```text
pinelib/
  __init__.py
  config.py
  errors.py
  version.py

  core/
    __init__.py
    runtime.py
    bar.py
    series.py
    types.py
    na.py
    precision.py
    operators.py
    casting.py
    scope.py
    registry.py

  ta/
    __init__.py
    sma.py
    ema.py
    rma.py
    wma.py
    vwma.py
    swma.py
    alma.py
    hma.py
    kama.py
    tr.py
    atr.py
    rsi.py
    macd.py
    stoch.py
    dmi.py
    supertrend.py
    bb.py
    kc.py
    sar.py
    cci.py
    mfi.py
    obv.py
    vwap.py
    pivot.py
    highest.py
    highestbars.py
    lowest.py
    lowestbars.py
    rising.py
    falling.py
    cross.py
    change.py
    roc.py
    mom.py
    correlation.py
    variance.py
    linreg.py
    percentile.py
    dev.py
    mode.py
    median.py
    valuewhen.py
    barssince.py

  math/
    __init__.py
    funcs.py

  request/
    __init__.py
    security.py
    merge.py
    providers.py
    timeframe.py

  strategy/
    __init__.py
    context.py
    orders.py
    broker.py
    trades.py
    commission.py
    slippage.py
    sizing.py
    risk.py

  input/
    __init__.py
    inputs.py

  color/
    __init__.py
    model.py
    palette.py

  string/
    __init__.py
    funcs.py

  array/
    __init__.py
    pine_array.py
    funcs.py

  matrix/
    __init__.py
    pine_matrix.py
    funcs.py

  map/
    __init__.py
    pine_map.py
    funcs.py

  syminfo/
    __init__.py
    model.py

  timeframe/
    __init__.py
    model.py
    parse.py

  barstate/
    __init__.py
    model.py

  visual/
    __init__.py
    plots.py
    drawings.py

  testing/
    __init__.py
    golden.py
    compare.py
    fixtures.py

tests/
  unit/
  golden/
  integration/
  fixtures/
```

---

## 4. Runtime core

### 4.1. `PineRuntime`

Нужен единый объект исполнения.

```python
class PineRuntime:
    def __init__(self, symbol_info, timeframe, data_provider=None, config=None):
        self.bar_index = -1
        self.current_bar = None
        self.series_registry: dict[str, Series] = {}
        self.indicator_state: dict[str, object] = {}
        self.strategy = None
        self.barstate = BarState()
        self.syminfo = symbol_info
        self.timeframe = timeframe
        self.data_provider = data_provider
        self.commit_order: list[str] = []

    def begin_bar(self, bar: Bar) -> None:
        """Установить OHLCV/time текущего бара и подготовить current-slot."""
        ...

    def end_bar(self) -> None:
        """Единственное место, где вызывается commit_current() для всех series."""
        for name in self.commit_order:
            self.series_registry[name].commit_current()
        self.bar_index += 1

    def series(self, name, dtype="float", initial=na) -> "Series":
        """Создать или вернуть зарегистрированную Series."""
        ...

    def get_indicator_state(self, state_id: str, factory):
        """Стабильное состояние stateful-индикаторов по state_id."""
        if state_id not in self.indicator_state:
            self.indicator_state[state_id] = factory()
        return self.indicator_state[state_id]
```

### 4.2. `Bar`

```python
@dataclass(frozen=True)
class Bar:
    # Unix timestamp в миллисекундах UTC, начало бара.
    time: int
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0
    # Unix timestamp в миллисекундах UTC, закрытие бара.
    time_close: int | None = None
```

### 4.2.1. Формат входных данных bars

Единый формат обязателен для PineLib, AST2Python integration tests и backtest engine.

**CSV:**

```csv
time,open,high,low,close,volume,time_close
1704067200000,42280.0,42500.0,42100.0,42450.0,1234.56,1704070799999
```

**Parquet schema:**

```text
time: int64        # Unix ms UTC, open time
open: float64
high: float64
low: float64
close: float64
volume: float64
time_close: int64 | null  # Unix ms UTC, close time
symbol: string | null     # optional
timeframe: string | null  # optional, Pine notation: "1", "5", "60", "D", "W"
```

Правила:

1. `time` и `time_close` всегда UTC Unix milliseconds.
2. Вход должен быть отсортирован по `time` ASC, без дублей.
3. `time_close` для минутных/часовых баров должен соответствовать правой границе бара минус 1 мс, если провайдер так выгружает TradingView-compatible данные; если нет — runtime должен уметь пересчитать по timeframe.
4. Отсутствующие бары не заполняются silently. Политика gaps задаётся явно в DataProvider/request merge.
5. Валидация входа должна падать ошибкой `PineDataFormatError`, если `high < max(open, close)` или `low > min(open, close)`.

### 4.3. `Series`

```python
class Series(Generic[T]):
    name: str
    dtype: PineType
    values: list[T]

    @property
    def current(self) -> T:
        ...

    def set_current(self, value: T) -> None:
        ...

    def commit_current(self) -> None:
        ...

    def __getitem__(self, offset: int) -> T:
        ...
```

**Обязательные правила:**

1. `series[0] == series.current`.
2. `series[1]` возвращает предыдущее committed-значение, а не значение, которое только что было изменено внутри текущего бара.
3. `set_current(value)` вызывается сгенерированным кодом сколько угодно раз внутри бара.
4. `commit_current()` вызывает только `PineRuntime.end_bar()` после завершения `_process_bar()` и broker/order processing по выбранной модели расчёта.
5. Для `bool` при отсутствии истории возвращать `False`.
6. Для `float/int/object/color/string` при отсутствии истории возвращать `na`.
7. Запретить `series[1][2]` на уровне AST2Python, но PineLib должна вести себя предсказуемо и выдавать диагностическую ошибку, если такое всё же дошло до runtime.

Нормативный loop:

```python
for bar in bars:
    runtime.begin_bar(bar)
    generated_strategy._process_bar(runtime)
    runtime.strategy.process_orders_for_bar(runtime)  # если strategy-mode
    runtime.end_bar()  # commit всех Series только здесь
```

### 4.4. `var` и `varip`

PineLib должна предоставить базовую поддержку персистентных переменных:

- `normal` — пересчитывается каждый бар.
- `var` — инициализируется один раз и сохраняется между барами.
- `varip` — сохраняется внутри realtime bar/tick; для исторического backtest MVP допускается поведение как `var`, но API должен быть заложен отдельно.

---

## 5. Типы и операторы

### 5.1. Базовые типы

```text
int
float
bool
string
color
array<T>
matrix<T>
map<K,V>
UDT/object
series<T>
simple<T>
input<T>
const<T>
```

### 5.2. Автокастинг

Требуется реализовать Pine-совместимые операции:

- `int + float -> float`
- `int / int -> float`
- сравнения с `na` не должны давать обычное Python-поведение;
- boolean-context для `na` запрещён/контролируем;
- `and`/`or` должны иметь short-circuit semantics.

### 5.3. `na` propagation

Если числовая операция получает `na`, результат `na`, кроме функций, где Pine явно заменяет `na` (`nz`, `fixnan`, некоторые overload-режимы `ta.tr(true)`).


### 5.4. Type/Qualifier и reference semantics

PineLib должна поддерживать runtime-валидацию типов, если AST2Python передал metadata типа/qualifier.

Qualifier lattice:

```text
const < input < simple < series
```

Обязательные правила:

1. Builtin overload выбирается по `base_type` и `qualifier`.
2. `series` нельзя silently передавать туда, где Pine требует `simple`.
3. `bool` в Pine v6 не может быть `na`; `na/nz/fixnan` с bool — ошибка.
4. `input` значения считаются стабильными на весь backtest, если optimizer не запускает отдельный прогон.
5. `simple` значения могут зависеть от runtime context, но не иметь bar-by-bar series history.

Reference types:

```text
array<T>
matrix<T>
map<K,V>
UDT/object
visual object id
```

Правила reference semantics:

1. Присваивание array/map/matrix/UDT копирует ссылку, если Pine-compatible fixture не требует deep copy.
2. `array.copy()`/`matrix.copy()`/`map.copy()` должны иметь явно зафиксированную shallow/deep semantics по golden/property tests.
3. Мутация через `array.set/push/pop`, `map.put/remove`, `matrix.set` меняет объект по id.
4. `var` reference object инициализируется один раз и сохраняет identity между барами.
5. History reference для reference object должен возвращать Pine-compatible snapshot/reference behavior, подтверждённый fixture; до подтверждения — P1 feature flag `reference_history_mode`.
6. UDT field mutation должна сохраняться согласно ownership объекта, а не создавать неявную копию.

---

## 6. NA, NZ, FIXNAN

### 6.1. API

```python
na = float("nan")

def is_na(value) -> bool:
    ...

def nz(x, replacement=0):
    ...

def fixnan(x):
    ...
```

### 6.2. Требования

1. `is_na(None) == True`.
2. `is_na(float("nan")) == True`.
3. `is_na(PineNA) == True`, если будет отдельный sentinel.
4. `nz(na) == 0`.
5. `nz(na, y) == y`.
6. `fixnan(series)` должен возвращать последнее не-`na` значение series.
7. Для bool-аргументов в v6 — ошибка совместимости.

---

## 7. TA-модуль

### 7.1. Общий контракт функций

Все TA-функции должны иметь два режима:

1. **Batch mode** — принимает list/array/Series и возвращает list/Series. Нужен для тестов, быстрой валидации и возможной векторизации.
2. **Runtime mode** — вызывается на каждом баре и возвращает текущее значение, при этом внутреннее состояние индикатора хранится в `PineRuntime`.

Пример:

```python
ema(source, length, *, runtime=None, state_id=None)
```

Если `runtime` передан — работает как Pine-вызов на текущем баре. Если нет — batch.

### 7.2. `ta.sma(source, length)`

**Правила:**

- Возвращает `na`, пока не накоплено `length` валидных значений.
- `na` внутри окна должен обрабатываться согласно Pine-поведению, подтверждённому golden-тестами.
- На MVP зафиксировать выбранное поведение тестами.

### 7.3. `ta.ema(source, length)`

```text
alpha = 2 / (length + 1)
seed = SMA первых length значений
ema = alpha * source + (1 - alpha) * prev_ema
```

**Acceptance:**

- До seed-периода — `na`.
- На seed-баре — SMA.
- Далее — рекуррентная EMA.
- Совпадение с TradingView golden fixture по tolerance.

### 7.4. `ta.rma(source, length)`

```text
seed = SMA первых length значений
rma = (prev_rma * (length - 1) + source) / length
```

Используется для ATR, RSI, DMI/ADX.

### 7.5. `ta.tr`

Поддержать:

- `ta.tr` как переменную True Range текущего бара.
- `ta.tr(true)` как функцию, использующую `high - low`, если `close[1]` недоступен.

Формула:

```text
TR = max(
  high - low,
  abs(high - close[1]),
  abs(low - close[1])
)
```

### 7.6. `ta.atr(length)`

```text
ATR = RMA(TR, length)
```

### 7.7. `ta.rsi(source, length)`

```text
change = source - source[1]
gain = max(change, 0)
loss = max(-change, 0)
avg_gain = RMA(gain, length)
avg_loss = RMA(loss, length)
RSI = 100 - 100 / (1 + avg_gain / avg_loss)
```

**Edge cases:**

- `avg_loss == 0` и `avg_gain > 0` => 100.
- `avg_gain == 0` и `avg_loss > 0` => 0.
- оба 0 => проверить по TV fixture и зафиксировать.

### 7.8. `ta.macd(source, fast, slow, signal)`

Возвращает tuple:

```text
(macd_line, signal_line, histogram)
```

### 7.9. `ta.supertrend(factor, atrPeriod)`

Возвращает tuple:

```text
(supertrend_line, direction)
```

**Нормативная конвенция TradingView:**

- `direction = -1` — bullish/uptrend, линия SuperTrend находится ниже цены и обычно рисуется как green/up trend.
- `direction = +1` — bearish/downtrend, линия SuperTrend находится выше цены и обычно рисуется как red/down trend.

Эта конвенция намеренно фиксируется в ТЗ, потому что многие сторонние реализации используют обратный знак.

**Обязательные golden-кейсы:**

- `fixtures/tradingview/supertrend_direction_up.csv` — переключение в bullish/uptrend, ожидается `direction=-1`.
- `fixtures/tradingview/supertrend_direction_down.csv` — переключение в bearish/downtrend, ожидается `direction=+1`.
- `fixtures/tradingview/supertrend_sideways.csv` — flat/sideways без ложного переключения.
- `fixtures/tradingview/supertrend_gaps.csv` — gap-сегменты.

Acceptance: `supertrend_line` и `direction` должны совпадать с TradingView на всех барах после warmup. До warmup допускается только такое `na`/initial-поведение, которое подтверждено fixture.

### 7.10. `ta.stoch`

Важно: в Pine `ta.stoch(source, high, low, length)` возвращает fast stochastic value; сглаживание через SMA не должно быть добавлено автоматически, если в Pine его нет в этой функции.

| Pine-вызов | Что возвращает | Сглаживание в PineLib |
|---|---|---|
| `ta.stoch(close, high, low, 14)` | Fast %K | Нет |
| `ta.sma(ta.stoch(close, high, low, 14), 3)` | Slow %K | Да, но только явным отдельным `ta.sma` |
| `[k, d]` из пользовательской функции | Tuple значений, заданных функцией | Только как в исходном Pine |

Golden tests:

- `test_stoch_fast_vs_tradingview()` — без скрытого SMA.
- `test_stoch_slow_explicit_sma_vs_tradingview()` — `sma(stoch, 3)` совпадает с TV.

### 7.11. `ta.dmi(length, adxSmoothing)`

Возвращает:

```text
(di_plus, di_minus, adx)
```

### 7.12. Остальные обязательные функции `ta.*`

```text
ta.alma
ta.barssince
ta.bb
ta.bbw
ta.cci
ta.change
ta.cmo
ta.cog
ta.correlation
ta.cross
ta.crossover
ta.crossunder
ta.dev
ta.ema
ta.falling
ta.highest
ta.highestbars
ta.hma
ta.kc
ta.kcw
ta.linreg
ta.lowest
ta.lowestbars
ta.macd
ta.median
ta.mfi
ta.mode
ta.mom
ta.obv
ta.percentile_linear_interpolation
ta.percentile_nearest_rank
ta.percentrank
ta.pivot_high / ta.pivothigh
ta.pivot_low / ta.pivotlow
ta.range
ta.rising
ta.rma
ta.roc
ta.rsi
ta.sar
ta.sma
ta.stdev
ta.stoch
ta.supertrend
ta.swma
ta.tr
ta.tsi
ta.valuewhen
ta.variance
ta.vwap
ta.vwma
ta.wma
```

---

## 8. Math-модуль

### 8.1. API

```text
math.abs
math.acos
math.asin
math.atan
math.avg
math.ceil
math.cos
math.exp
math.floor
math.log
math.log10
math.max
math.min
math.pow
math.random
math.round
math.round_to_mintick
math.sign
math.sin
math.sqrt
math.sum
math.tan
math.todegrees
math.toradians
```

### 8.2. Alias-импорты

Так как `abs`, `round`, `min`, `max`, `sum` конфликтуют с Python builtins, AST2Python должен импортировать их как:

```python
from pinelib.math import pine_abs, pine_round, pine_min, pine_max, pine_sum
```

PineLib должна экспортировать оба API:

```python
math.abs
pine_abs
```

---

## 9. String-модуль

```text
str.contains
str.endswith
str.format
str.format_time
str.length
str.lower
str.match
str.pos
str.replace
str.replace_all
str.split
str.startswith
str.substring
str.tonumber
str.tostring
str.trim
str.upper
```

**Требование:** `str.tostring` должен поддерживать форматирование чисел, bool, color, `na`, mintick-формат и шаблоны, которые реально встречаются в стратегиях.

---

## 10. Color-модуль

### 10.1. Модель цвета

```python
@dataclass(frozen=True)
class PineColor:
    r: int
    g: int
    b: int
    a: int  # alpha 0..255 или transparency 0..100 через адаптер
```

### 10.2. API

```text
color.rgb
color.new
color.t
color.r
color.g
color.b
color.from_gradient

color.black
color.silver
color.gray
color.white
color.maroon
color.red
color.purple
color.fuchsia
color.green
color.lime
color.olive
color.yellow
color.navy
color.blue
color.teal
color.aqua
color.orange
```

---

## 11. Array, matrix, map

### 11.1. Array

```text
array.new<T>
array.new_float
array.new_int
array.new_bool
array.new_string
array.new_color
array.get
array.set
array.push
array.pop
array.unshift
array.shift
array.insert
array.remove
array.clear
array.size
array.slice
array.concat
array.copy
array.indexof
array.lastindexof
array.includes
array.sort
array.reverse
array.range
array.avg
array.median
array.stdev
array.variance
array.sum
array.min
array.max
```

### 11.2. Matrix

```text
matrix.new<T>
matrix.get
matrix.set
matrix.rows
matrix.columns
matrix.elements_count
matrix.add_row
matrix.add_col
matrix.remove_row
matrix.remove_col
matrix.reshape
matrix.reverse
matrix.row
matrix.col
matrix.transpose
matrix.mult
matrix.sum
matrix.diff
matrix.avg
matrix.median
matrix.mode
matrix.min
matrix.max
```

### 11.3. Map

```text
map.new<K,V>
map.get
map.put
map.put_all
map.remove
map.size
map.clear
map.keys
map.values
map.contains
map.copy
```

---

## 12. `request.*` и multi-timeframe

### 12.1. DataProvider

```python
class DataProvider(Protocol):
    def get_bars(self, symbol: str, timeframe: str, start: int | None, end: int | None) -> list[Bar]:
        ...
```

### 12.2. `request.security`

```python
def security(
    symbol: str,
    timeframe: str,
    expression_callable,
    *,
    gaps="barmerge.gaps_off",
    lookahead="barmerge.lookahead_off",
    ignore_invalid_symbol=False,
    currency=None,
    calc_bars_count=None,
    runtime: PineRuntime,
    state_id: str,
):
    ...
```

`expression_callable` — не заранее вычисленное значение, а функция, которая принимает временный runtime requested-context.

```python
def security(symbol, tf, expression_callable, *, runtime, state_id, **merge_opts):
    htf_bars = runtime.data_provider.get_bars(symbol, tf, runtime.range_start, runtime.range_end)
    req_rt = runtime.spawn_child_context(
        symbol=symbol,
        timeframe=tf,
        namespace=f"{state_id}:request",
    )
    requested_values = []
    for bar in htf_bars:
        req_rt.begin_bar(bar)
        value = expression_callable(req_rt)  # close/high/low берутся из req_rt
        requested_values.append(value)
        req_rt.end_bar()
    return merge_requested_series_to_chart_bars(
        requested_values,
        requested_bars=htf_bars,
        chart_bars=runtime.chart_bars,
        gaps=merge_opts.get("gaps", "barmerge.gaps_off"),
        lookahead=merge_opts.get("lookahead", "barmerge.lookahead_off"),
    )[runtime.bar_index]
```

Критично: если expression содержит `ta.ema(close, 200)`, то `close` должен быть `req_rt.close`, а stateful EMA должна жить в `req_rt.indicator_state`, namespaced через `state_id` security-вызова.

### 12.3. Обязательная семантика merge

Поддержать:

```text
barmerge.gaps_on
barmerge.gaps_off
barmerge.lookahead_on
barmerge.lookahead_off
```

### 12.4. Dynamic requests Pine v6

В Pine v6 `request.*` динамические по умолчанию. PineLib должна разрешать:

- series-аргументы symbol/timeframe;
- вызов внутри `if`, `for`, функций;
- вложенные requests, если это потребуется.

MVP-правило: вложенные requests не реализуются до отдельного milestone. При попытке выполнить `request.security` внутри `expression_callable` другого `request.security` PineLib должна выбросить:

```python
raise PineUnsupportedFeatureError(
    code="PL_UNSUPPORTED_NESTED_SECURITY",
    message="Nested request.security is not supported in PineLib MVP"
)
```

AST2Python при генерации должен дополнительно выдавать `P2A_WARNING_NESTED_SECURITY` или compile error в strict mode.

### 12.5. `request.security_lower_tf`

Возвращает array значений нижнего таймфрейма внутри текущего бара старшего таймфрейма.

MVP: допускается stub с явной ошибкой `NotImplementedError`, если целевые стратегии не используют LTF. Но API должен быть зарезервирован.

### 12.6. Остальные request-функции

```text
request.dividends
request.earnings
request.economic
request.financial
request.quandl
request.seed
request.splits
```

MVP: допускаются stubs с диагностикой и тестами, если не используются в целевых стратегиях.

---

## 13. Strategy runtime и broker emulator

### 13.1. Главный объект

```python
class StrategyContext:
    def __init__(
        self,
        initial_capital=100000.0,
        currency="USD",
        commission_type="percent",
        commission_value=0.0,
        slippage=0,
        pyramiding=1,
        default_qty_type="fixed",
        default_qty_value=1.0,
        process_orders_on_close=False,
        calc_on_order_fills=False,
        calc_on_every_tick=False,
        use_bar_magnifier=False,
    ):
        ...
```

### 13.2. API strategy.*

```text
strategy.entry
strategy.exit
strategy.order
strategy.close
strategy.close_all
strategy.cancel
strategy.cancel_all

strategy.equity
strategy.initial_capital
strategy.netprofit
strategy.openprofit
strategy.grossprofit
strategy.grossloss
strategy.position_size
strategy.position_avg_price
strategy.position_entry_name
strategy.opentrades
strategy.closedtrades
strategy.wintrades
strategy.losstrades
strategy.eventrades
strategy.max_drawdown
strategy.max_runup
```

### 13.3. Типы ордеров

Поддержать:

- market
- limit
- stop
- stop-limit
- bracket exits через `strategy.exit`
- partial exits через `qty` / `qty_percent`
- OCA reduce semantics для нескольких exits
- pyramiding
- long/short reversal при `strategy.entry`

### 13.4. Правила исполнения ордеров

MVP должен воспроизводить базовые правила TradingView:

1. Market order исполняется на следующем доступном тике.
2. При стандартном historical backtest без tick data следующий доступный тик после закрытия бара — open следующего бара.
3. Для OHLC path без bar magnifier использовать правила TradingView:
   - если `abs(open - high) < abs(open - low)`, путь `open -> high -> low -> close`;
   - иначе путь `open -> low -> high -> close`;
   - внутри бара нет gap между OHLC-точками, любая цена внутри high-low диапазона доступна;
   - если price-based order пересечён только в gap между `prev_close` и `open`, fill происходит по `open` текущего бара, а не по order price.
4. `strategy.exit(limit=..., stop=...)` создаёт два exit-ордера — take-profit и stop-loss, а не stop-limit.
5. Если в `strategy.exit` заданы `qty` и `qty_percent`, приоритет у `qty`.
6. `from_entry` ограничивает exit конкретным entry id.
7. `strategy.exit` без `from_entry` применяется ко всем подходящим открытым сделкам и имеет persist-семантику до закрытия позиции.
8. Комиссия и slippage должны применяться в момент fill.

### 13.5. OCA/reservation semantics для `strategy.exit`

TradingView-совместимые правила для MVP:

1. Один `strategy.exit(id, from_entry, limit=..., stop=...)` создаёт bracket-группу; если сработал limit или stop, второй order из этой же bracket-группы автоматически отменяется.
2. Все exit-ордера, созданные через `strategy.exit`, по умолчанию принадлежат OCA reduce group.
3. Несколько `strategy.exit` для одного `from_entry` резервируют части позиции в порядке вызовов в исходном коде.
4. `qty` имеет приоритет над `qty_percent`.
5. Если суммарные `qty`/`qty_percent` превышают доступную открытую позицию, runtime не должен открывать обратную позицию; он уменьшает размеры последующих exits до доступного остатка и пишет diagnostic `PL_WARNING_EXIT_QTY_REDUCED`.
6. Если `qty_percent > 100` или сумма planned exits > 100%, diagnostic обязателен даже если TradingView автоматически уменьшает размер.
7. `strategy.exit` без `from_entry` сохраняет persist-семантику: создаёт exits для всех текущих и будущих entries до полного закрытия позиции.

### 13.6. Trade log

Каждая сделка должна иметь:

```python
@dataclass
class Trade:
    entry_id: str
    direction: Literal["long", "short"]
    entry_time: int
    entry_bar_index: int
    entry_price: float
    exit_time: int | None
    exit_bar_index: int | None
    exit_price: float | None
    qty: float
    commission: float
    profit: float
    profit_percent: float
    exit_reason: str | None
```

### 13.7. Acceptance для strategy

Для целевых стратегий AVAX/SOL/XLM:

- совпадение количества сделок;
- совпадение entry/exit bar_index;
- совпадение entry/exit price в пределах tolerance;
- совпадение direction;
- совпадение qty с учётом precision;
- совпадение PnL/equity curve.


### 13.8. Полный mapping `strategy()` declaration

PineLib должна принимать и хранить все параметры `strategy(...)`, которые влияют на backtest. AST2Python передаёт их в `StrategyContext`, а PineLib либо реализует параметр, либо явно диагностирует неподдержку.

| Pine parameter | StrategyContext field | Приоритет | Поведение |
|---|---|---:|---|
| `initial_capital` | `initial_capital` | P0 | начальный капитал equity |
| `currency` | `currency` | P0 | валюта отчёта и PnL |
| `default_qty_type` | `default_qty_type` | P0 | `fixed`, `cash`, `percent_of_equity` |
| `default_qty_value` | `default_qty_value` | P0 | default sizing для orders без qty |
| `pyramiding` | `pyramiding` | P0 | лимит одновременных entries в одном направлении |
| `commission_type` | `commission_type` | P0 | percent/cash_per_order/cash_per_contract |
| `commission_value` | `commission_value` | P0 | значение комиссии |
| `slippage` | `slippage` | P0 | ticks или price-adjustment по runtime config |
| `process_orders_on_close` | `process_orders_on_close` | P0 | разрешает fill на close текущего бара |
| `calc_on_order_fills` | `calc_on_order_fills` | P0 | включает повторный расчёт после fill |
| `calc_on_every_tick` | `calc_on_every_tick` | P1 | historical MVP: diagnostic/fallback, realtime milestone |
| `use_bar_magnifier` | `use_bar_magnifier` | P0 | включает intrabar provider |
| `backtest_fill_limits_assumption` | `backtest_fill_limits_assumption` | P1 | stricter fills для limit orders |
| `close_entries_rule` | `close_entries_rule` | P1 | FIFO/ANY, если встречается в целевых стратегиях |
| `margin_long` / `margin_short` | `margin_long` / `margin_short` | P1 | leverage/margin model |
| `risk_free_rate` | `risk_free_rate` | P2 | только метрики, не fills |
| `max_bars_back` | `max_bars_back` | P0 | history/warmup depth |
| `max_lines_count` / `max_labels_count` / `max_boxes_count` | visual limits | P1 | лимиты recorder-объектов |

Правило unsupported-параметров:

- `strict_tv_parity=True`: ошибка `PL_UNSUPPORTED_STRATEGY_SETTING` до запуска backtest.
- `strict_tv_parity=False`: diagnostic warning, параметр сохраняется в metadata и отчёте расхождений.
- Нельзя silently ignore параметры, которые влияют на сделки, размер позиции, цену fill или equity.

### 13.9. Strategy execution schedule

Runtime обязан иметь детерминированный schedule исполнения. Это нормативный порядок для historical strategy-mode без realtime ticks:

```python
for bar in chart_bars:
    runtime.begin_bar(bar)
    runtime.update_barstate(bar)

    generated_strategy._process_bar(runtime)
    runtime.strategy.accept_orders_from_generated_code()

    runtime.strategy.process_orders_for_bar(
        runtime=runtime,
        bar=bar,
        intrabar_bars=runtime.intrabar_provider.get_intrabar_bars(...) if use_bar_magnifier else None,
    )

    while runtime.strategy.has_fill_recalc_pending() and runtime.config.calc_on_order_fills:
        runtime.guard_recalc_count(max_recalculations_per_bar)
        runtime.strategy.update_position_equity_trades_after_fill()
        generated_strategy._process_bar(runtime)
        runtime.strategy.accept_orders_from_generated_code()
        runtime.strategy.process_orders_for_bar(runtime=runtime, bar=bar, recalc_phase=True)

    runtime.end_bar()
```

Обязательные правила:

1. `generated_strategy._process_bar()` не исполняет fills и не меняет broker state напрямую.
2. `StrategyContext` обновляет `position_size`, `position_avg_price`, `equity`, `opentrades`, `closedtrades` сразу после fill и до повторного расчёта, если `calc_on_order_fills=True`.
3. `max_recalculations_per_bar` обязателен, чтобы стратегия не ушла в бесконечный цикл fill/recalc.
4. `process_orders_on_close=True` разрешает market/fill processing на close текущего бара согласно fixtures.
5. `calc_on_every_tick=True` в historical MVP не должен silently эмулироваться как обычный close-only режим: нужен diagnostic `PL_WARNING_CALC_ON_EVERY_TICK_FALLBACK`.
6. `barstate` должен отражать phase исполнения: historical close pass, fill recalculation pass, realtime/tick pass в будущих milestone.
7. `commit_current()` всё равно вызывается только в `runtime.end_bar()` после всех fill/recalc phases.

### 13.10. IntrabarDataProvider и Bar Magnifier

Если `use_bar_magnifier=True`, broker emulator должен использовать lower-timeframe бары вместо synthetic OHLC path.

```python
class IntrabarDataProvider(Protocol):
    def get_intrabar_bars(
        self,
        symbol: str,
        chart_bar: Bar,
        lower_timeframe: str | None = None,
        *,
        max_bars: int | None = None,
    ) -> list[Bar]: ...
```

Правила:

1. Intrabar bars должны лежать внутри `[chart_bar.time, chart_bar.time_close]`.
2. Intrabar bars сортируются ASC и проходят тот же OHLC/time validation.
3. Если intrabar data отсутствует:
   - `strict_tv_parity=True`: ошибка `PL_MISSING_INTRABAR_DATA`.
   - иначе: warning `PL_WARNING_BAR_MAGNIFIER_FALLBACK` и fallback на synthetic OHLC path.
4. При Bar Magnifier order fills моделируются по реальной последовательности intrabar bars, а не по chart OHLC assumptions.
5. Trade log должен сохранять `fill_source="intrabar" | "ohlc_path"`.
6. Golden fixtures должны отдельно покрывать TP/SL внутри одного chart-бара с Bar Magnifier и без него.

---

## 14. Input-модуль

```text
input
input.int
input.float
input.bool
input.string
input.text_area
input.time
input.timeframe
input.symbol
input.price
input.source
input.color
input.enum
input.session
```

### 14.1. Поведение

В runtime это не UI, а источник параметров.

```python
params = {
    "needLong": True,
    "emaLen": 200,
}
```

Если параметр не передан — используется default из Pine-кода.


### 14.2. Расширенный input metadata и validation

PineLib должна принимать input metadata от AST2Python и валидировать runtime params до начала backtest.

Обязательные поля input metadata:

```json
{
  "pine_name": "emaLen",
  "py_name": "ema_len",
  "type": "int",
  "default": 200,
  "title": "EMA Length",
  "minval": 1,
  "maxval": 1000,
  "step": 1,
  "options": null,
  "group": "Trend",
  "inline": null,
  "tooltip": null,
  "confirm": false,
  "display": "all",
  "active": true
}
```

Validation rules:

1. Если параметр отсутствует — использовать Pine default.
2. Если значение не входит в `options` — ошибка `PineInputError`.
3. Если значение ниже `minval` или выше `maxval` — ошибка `PineInputError`, не silent clamp.
4. `step` проверяется для int/float, но округление допускается только если golden fixture подтверждает TradingView-compatible поведение.
5. `input.source` должен указывать на допустимую series: `open/high/low/close/hl2/hlc3/ohlc4` или generated series, если Pine разрешает.
6. `input.session` передаётся в session parser без локального timezone-сдвига.
7. Metadata сохраняется в результатах backtest, чтобы optimizer мог воспроизвести точную конфигурацию.

---

## 15. syminfo, timeframe, barstate

### 15.1. syminfo

```text
syminfo.basecurrency
syminfo.currency
syminfo.description
syminfo.mintick
syminfo.mincontract
syminfo.pointvalue
syminfo.prefix
syminfo.root
syminfo.session
syminfo.ticker
syminfo.tickerid
syminfo.timezone
syminfo.type
```

### 15.2. timeframe

```text
timeframe.period
timeframe.multiplier
timeframe.isseconds
timeframe.isminutes
timeframe.isintraday
timeframe.isdaily
timeframe.isweekly
timeframe.ismonthly
```

### 15.3. barstate

```text
barstate.isfirst
barstate.islast
barstate.ishistory
barstate.isrealtime
barstate.isnew
barstate.isconfirmed
barstate.islastconfirmedhistory
```

Historical MVP:

- `isfirst == bar_index == 0`
- `islast == текущий бар последний в dataset`
- `ishistory == True`
- `isrealtime == False`
- `isnew == True`
- `isconfirmed == True`


### 15.4. Sessions, timezone и календарная семантика

PineLib должна реализовать session/time helpers так, чтобы `time()`, `time_close()`, `input.session` и `syminfo.timezone` не зависели от локальной timezone машины.

Обязательные элементы:

```text
input.session strings: "0900-1700", "0900-1700:12345", "1700-1700:23456"
regular/extended session flag через syminfo.session
exchange timezone через syminfo.timezone
time(timeframe, session, timezone)
time_close(timeframe, session, timezone)
year/month/weekofyear/dayofmonth/dayofweek/hour/minute/second
```

Правила:

1. Входные `Bar.time` и `Bar.time_close` всегда UTC Unix ms.
2. Все календарные функции вычисляются в `timezone`, если он указан, иначе в `syminfo.timezone`.
3. Если бар не входит в указанную session, `time()`/`time_close()` возвращают `na`.
4. Overnight sessions должны поддерживаться как диапазоны, пересекающие полночь exchange timezone.
5. DST-переходы не должны обрабатываться через fixed offset; нужен IANA timezone name.
6. Для crypto 24/7 default session должен быть явно задан в `SymbolInfo`, а не зашит в код.
7. Golden fixtures: обычная дневная сессия, overnight session, DST week, crypto 24/7, regular vs extended.

### 15.5. Visual object recorder

Даже если визуальные функции не влияют на сделки, они не должны ломать исполнение Pine-кода, где object id хранится в `var` или передаётся в `line.set_*`/`label.delete`.

Runtime должен иметь recorder API:

```python
obj_id = runtime.visual.line_new(..., source_map="L77")
runtime.visual.line_set_xy1(obj_id, x, y, source_map="L78")
runtime.visual.line_delete(obj_id, source_map="L79")
```

Правила:

1. `label.new`, `line.new`, `box.new`, `table.new` возвращают stable `PineObjectId`, а не `None`.
2. `set_*` и `delete` обновляют recorder state, но не рисуют UI.
3. Лимиты `max_lines_count`, `max_labels_count`, `max_boxes_count` соблюдаются или дают diagnostic.
4. Если visual object используется в торговой expression как числовое/булево значение — ошибка type checker/generator.
5. Recorder state может быть сохранён в debug artifact, но не обязателен для optimizer.

---

## 16. Precision, rounding, mintick

### 16.1. Настройки

```python
DEFAULT_PRECISION = 1e-10
FLOAT_COMPARE_REL_TOL = 1e-8
FLOAT_COMPARE_ABS_TOL = 1e-10
```

### 16.2. `math.round_to_mintick`

Должна использовать `syminfo.mintick`.

```python
def round_to_mintick(value, mintick):
    ...
```

### 16.3. Сравнение в тестах

Использовать:

```python
assert_pine_close(actual, expected, abs_tol=1e-10, rel_tol=1e-8)
```

Для trade prices допуск может зависеть от `mintick`.

---

## 17. Диагностика и ошибки

Создать отдельные исключения:

```text
PineRuntimeError
PineTypeError
PineNAError
PineHistoryError
PineRequestError
PineStrategyError
PineUnsupportedFeatureError
PineGoldenMismatchError
```

Ошибки должны содержать:

- имя функции;
- bar_index;
- исходный Pine fragment, если AST2Python передал source map;
- краткое объяснение;
- возможное исправление.

---

## 18. Тестирование

### 18.1. Unit tests

Минимальный набор:

```text
test_na.py
test_series.py
test_runtime.py
test_operators.py
test_sma.py
test_ema.py
test_rma.py
test_atr.py
test_rsi.py
test_macd.py
test_supertrend.py
test_dmi.py
test_cross.py
test_request_security_merge.py
test_strategy_orders.py
test_strategy_oca_reduce.py
test_data_format.py
test_pine_range.py
```

### 18.2. Golden tests

Для каждого важного индикатора:

```text
fixtures/tradingview/ema.csv
fixtures/tradingview/rma.csv
fixtures/tradingview/atr.csv
fixtures/tradingview/rsi.csv
fixtures/tradingview/macd.csv
fixtures/tradingview/supertrend.csv
fixtures/tradingview/supertrend_direction_up.csv
fixtures/tradingview/supertrend_direction_down.csv
fixtures/tradingview/supertrend_sideways.csv
fixtures/tradingview/dmi.csv
fixtures/tradingview/bb.csv
fixtures/tradingview/security_htf.csv
fixtures/tradingview/strategy_trades_avax.csv
```

CSV должен содержать:

```text
time,open,high,low,close,volume,expected_...
```

### 18.3. Property tests

Использовать Hypothesis опционально:

- EMA на константной series должна давать константу после seed.
- SMA window должен совпадать с ручным расчётом.
- `highest >= source` внутри окна.
- `cross/crossover/crossunder` не должны одновременно давать невозможные состояния.

### 18.4. Integration tests

```python
def test_avax_strategy_1_to_1():
    """
    Pine source -> Pine2AST -> AST2Python -> generated Python -> PineLib runtime.
    Сравниваем с TradingView:
    - индикаторные колонки,
    - сигналы,
    - сделки,
    - equity curve.
    """
```

---

## 19. Definition of Done

PineLib считается готовой для MVP, если:

1. Все unit tests зелёные.
2. Все golden tests по M1-M5 зелёные.
3. AVAX strategy даёт не менее 95% совпадения сделок на первом milestone integration.
4. После реализации strategy broker — 100% совпадение количества сделок и direction.
5. Entry/exit bar_index совпадают 100% на эталонном dataset.
6. PnL отличается не более чем на tolerance, объяснённый commission/slippage/mintick.
7. Все unsupported-функции падают явно, а не молча возвращают неверный результат.
8. Пакет устанавливается через `pip install -e .`.
9. Есть README с примерами runtime-вызова.
10. Есть CHANGELOG и карта покрытия Pine-функций.

---

## 20. Milestones

| Этап | Содержание | Результат | Оценка |
|---|---|---|---:|
| M1 | Core runtime: Bar, Series, NA, precision, runtime loop | `Series`, `PineRuntime`, базовые tests | 2-3 дня |
| M2 | Operators/types/casting, bool v6 semantics | корректные операции и history | 2-3 дня |
| M3 | TA base: SMA, EMA, RMA, TR, ATR, RSI | golden по базовым индикаторам | 3-4 дня |
| M4 | TA extended: MACD, STOCH, DMI, BB, highest/lowest, cross | покрытие популярных функций | 3-5 дней |
| M5 | TA advanced: supertrend, SAR, pivot, valuewhen, barssince, linreg, percentiles | покрытие целевых стратегий | 4-6 дней |
| M6 | Math, string, color, input | вспомогательные namespaces | 2-3 дня |
| M7 | array, matrix, map | структуры данных Pine | 3-5 дней |
| M8 | syminfo, timeframe, barstate | runtime metadata | 1-2 дня |
| M9 | request.security + merge semantics | HTF/LTF адаптеры | 4-7 дней |
| M10 | strategy context + broker emulator MVP | сделки и equity | 5-10 дней |
| M11 | Golden/integration validation | AVAX/SOL/XLM validation | 4-7 дней |
| M12 | Optimization pass | NumPy/Numba только после точности | 2-5 дней |

**Итого реалистично:** 35-60 календарных дней для качественного MVP с strategy parity.  
**Ускоренный вариант под одну целевую стратегию:** 18-30 дней.

---

## 21. Риски

| Риск | Вероятность | Влияние | Как снизить |
|---|---:|---:|---|
| Неверная семантика `request.security` | высокая | критично | отдельные golden fixtures по lookahead/gaps |
| Неверный broker emulator | высокая | критично | сначала простые strategy fixtures, потом AVAX |
| Путаница batch/runtime TA | средняя | высокое | единый state_id/runtime contract |
| `na` и bool v6 | средняя | высокое | typed Series и тесты v6 |
| Разные mintick/commission/slippage | высокая | высокое | syminfo fixture + точная настройка StrategyContext |
| Слишком ранняя оптимизация | средняя | среднее | запрет numba до golden parity |

---

## 22. Карта приоритетов реализации

### P0 — обязательно для первой рабочей стратегии

```text
core.Series
core.PineRuntime
na/nz/fixnan
math basic
ta.sma/ema/rma/tr/atr/rsi/macd/highest/lowest/cross/change/bb/supertrend
input basic
syminfo/timeframe/barstate basic
strategy.entry/exit/close/order basic
request.security HTF gaps/lookahead MVP
```

### P1 — после первого совпадения сделок

```text
array
string full
color full
dmi/stoch/sar/pivot/valuewhen/barssince
advanced broker orders
commission/slippage/mintick edge cases
sessions/timezone/input validation
bar magnifier contract + diagnostics
```

### P2 — полное покрытие Pine runtime

```text
matrix/map
financial/economic/quandl requests
visual objects stable ids
tables/labels/lines recorder
realtime tick model
```

---

## 23. Runtime Contract reference

Полный контракт вынесен в отдельный файл комплекта: `runtime_contract.md`. PineLib обязана реализовать все интерфейсы из этого файла без изменения сигнатур. Изменение контракта допускается только через версионирование `contract_version` и синхронное обновление AST2Python.

Минимальный smoke-test совместимости:

```python
runtime = PineRuntime(symbol_info=SymbolInfo(tickerid="BINANCE:AVAXUSDT.P"), timeframe="60", data_provider=provider)
strategy = GeneratedStrategy(params={}, runtime=runtime)
results = strategy.run(provider.get_bars("BINANCE:AVAXUSDT.P", "60", start, end))
assert runtime.contract_version == "1.4"
```


## 24. Источники и ориентиры

- TradingView Pine Script v6 User Manual — Execution model
- TradingView Pine Script v6 User Manual — Operators / history-referencing operator
- TradingView Pine Script v6 User Manual — Other timeframes and data / request.security
- TradingView Pine Script v6 User Manual — Strategies
- TradingView Pine Script v6 Migration Guide — bool values cannot be na
- TradingView Pine Script v6 Reference Manual — built-ins
