# Semantic Versioning Policy

PineLib follows semver-style expectations while pre-1.0:

- `0.MINOR.0`: staged runtime milestone. May add APIs, harden behavior, or make documented breaking changes with migration notes.
- `0.MINOR.PATCH`: bug fixes, docs, test hardening, compatible diagnostics additions.
- `1.0.0`: first stable API contract for generated-code consumers.

## What counts as breaking before 1.0

- Removing or renaming a `pinelib.__all__` export.
- Changing a documented error code for the same condition.
- Silently approximating an unsupported TradingView feature instead of raising/diagnosing it.
- Changing JSON report fields without a migration note.

## What is compatible

- Adding new helpers, optional fields, diagnostics, tests, docs, or stricter validation for invalid inputs.
- Raising explicit `PineRuntimeError`/subclasses where previous behavior was undefined.
- Performance improvements that keep observable results unchanged.

## TradingView parity language

Release notes must distinguish implemented behavior, tested scaffold/harness support, and deferred parity. Do not claim full TV parity without fixtures and acceptance gates.
