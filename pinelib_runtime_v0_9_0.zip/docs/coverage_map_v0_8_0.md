# PineLib Runtime v0.8.0 Coverage Map

Runtime contract: `runtime_contract_v1.4` / `TZ_01` track.

## Implemented namespaces and surfaces

- `pinelib.core`: `Bar`, `Series`, `PineRuntime`, inputs, runtime config diagnostics, timeframe/session helpers, Pine-style NA and arithmetic helpers.
- `pinelib.ta`: batch/runtime stateful coverage for common SMA/EMA/RMA/RSI/MACD/TR/ATR/cross helpers plus v0.6 indicator expansion (`bb`, `stoch`, `dmi/adx`, `supertrend`, moving-average variants, pivots, `valuewhen`, `barssince`, statistics, VWAP/MFI/CCI/OBV/MOM/ROC/correlation/rising/falling).
- `pinelib.request`: in-memory providers, `request.security` foundation, merge behavior, nested-request diagnostics.
- `pinelib.strategy`: broker emulator MVP, entries/orders/exits/closes, OHLC path fills, Bar Magnifier fallback/provenance, order-fill recalculation guard, `process_orders_on_close`, FIFO/ANY close matching basics, margin field diagnostics.
- `pinelib.backtest`: generated-strategy runner, snapshots, JSON-safe backtest report schema, golden JSON compare.
- `pinelib.parity`: TradingView indicator/trade CSV fixture loaders, indicator and strategy/equity tolerance compare reports, AVAX/SOL/XLM sample data contracts.
- `pinelib.io`: CSV OHLCV loader and optional Parquet loader with clear dependency diagnostics.
- `pinelib.visual`: visual event recorder foundation.
- `pinelib.reference`: array/map/matrix containers with explicit reference-history limitations.
- `pinelib.math`, `pinelib.string`, `pinelib.color`: basic namespace helpers used by generated code.

## Explicitly partial / diagnostic-only

- TradingView Strategy Tester parity is fixture-driven and tolerance-based; full tester clone behavior is not claimed.
- Trailing exits remain diagnostic-only in v0.8.0; no stateful trailing-stop ratchet is emulated yet.
- Margin fields are accepted and reported in diagnostics, but liquidation/margin-call behavior is not emulated.
- `calc_on_every_tick` emits a historical-fallback diagnostic; realtime tick execution is deferred.
- `backtest_fill_limits_assumption` is unsupported and emits/raises via strict parity settings.
- Bar Magnifier requires valid intrabar bars; otherwise it falls back or raises in strict modes.
- Some TA overloads remain batch-first or require explicit runtime `state_id`.

## Target strategy integration scaffolding

`docs/sample_contracts_v0_8_0.json` defines placeholder data contracts for AVAX, SOL, and XLM. Replace each placeholder path with TradingView-exported:

- chart OHLCV bars CSV (`time,open,high,low,close[,volume,time_close]`)
- indicator export CSV (`time` plus plotted/diagnostic columns)
- strategy trades CSV
- equity CSV

Use `pinelib.parity` loaders and compare reports to gate generated strategy integration.
