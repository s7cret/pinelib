# Migration Guide: v0.8.0 to v0.9.0

v0.9.0 is a hardening release. Most v0.8 generated-code consumers should work unchanged.

## Required checks

1. Update package/version expectations from `0.8.0` to `0.9.0`.
2. Treat `pinelib.__all__` as the supported top-level import surface. Move private-module imports to public exports where possible.
3. If packaging typed integrations, include `pinelib/py.typed` and run `mypy pinelib` in CI.
4. Review `docs/coverage_map_v0_9_0.md` for explicit unsupported parity areas.

## Behavior to notice

- Tests now pin stop-limit broker behavior, `close_entries_rule="ANY"` targeting, invalid request merge args, DST fall-back behavior, stricter input failures, visual delete/set failures, and TA invalid length/type failures.
- Performance smoke tests are present to catch accidental severe regressions; they are not microbenchmark targets.
- CI now runs compile, pytest, mypy, and release script smoke on Python 3.11-3.13.

## No fake parity

If a TradingView feature is missing, keep it as explicit diagnostic/error behavior. Do not approximate silently in generated adapters.
