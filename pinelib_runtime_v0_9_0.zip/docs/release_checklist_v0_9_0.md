# Release Checklist v0.9.0

- [x] Version bumped to `0.9.0` in `pyproject.toml` and `pinelib/version.py`.
- [x] Public API review documented.
- [x] Semver policy documented.
- [x] Coverage/limitations map updated.
- [x] Migration guide from v0.8.0 added.
- [x] Edge tests added for broker, request merge, sessions/DST, inputs, visual/reference, TA, and public exports.
- [x] `py.typed` added for typed package consumers.
- [x] Performance smoke benchmarks added.
- [x] GitHub Actions CI added.
- [x] `README.md` and `CHANGELOG_v0.9.0.md` updated.
- [x] Gates pass: `python -m compileall pinelib tests scripts`, `pytest -q`, `mypy pinelib`, `python scripts/build_release.py`.
- [x] Archive and manifest generated: `pinelib_runtime_v0_9_0.zip`, `RELEASE_MANIFEST_v0_9_0.json`.
- [x] Commit created: `Release pinelib runtime v0.9.0`.
