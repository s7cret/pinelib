# PineLib Runtime v0.9.0 Coverage and Limitations Map

Built against `runtime_contract_v1.4` / `TZ_01` as a release candidate before 1.0 API stabilization.

## Covered with tests

- Bar validation and UTC millisecond timestamps.
- Series current/committed history model and NA/operator helpers.
- Runtime bar loop, built-in OHLCV series, metadata, diagnostics, inputs, barstate, symbol/timeframe info.
- Inputs: int/float/bool/string/timeframe/symbol/session/source metadata and validation edge cases.
- Sessions/timezones: IANA zones, regular and overnight sessions, DST spring/fall behavior, calendar helpers.
- Request security foundation: in-memory providers, child runtime isolation, gaps/lookahead merge modes, invalid modes, missing symbol ignore, nested request diagnostic.
- Strategy broker MVP: market/limit/stop/stop-limit order fills, next-bar vs close processing, reversal, pyramiding, exit reservations, OCA reduce, ANY close entry selection, commission/slippage/sizing, Bar Magnifier fallback/provenance.
- Backtest runner/report snapshots and golden/strategy compare helpers.
- Parity fixture harnesses for TradingView indicator/trade CSV exports and sample contracts.
- Visual/reference foundations: deterministic visual event recorder, object limits, array/map/matrix shallow-copy semantics, unsupported reference history diagnostic.
- TA namespace: tested batch/runtime core helpers plus extended v0.6 helper set; runtime stateful helpers require explicit stable `state_id`.
- Smoke performance for runtime+TA and broker loops; not a tuning benchmark.

## Explicit limitations

- No fake TradingView parity: unimplemented overloads/settings raise diagnostics/errors rather than pretending.
- Realtime tick execution and full `calc_on_every_tick` semantics are not implemented; historical fallback diagnostic only.
- Strategy tester parity remains partial: no margin calls/liquidation model, no full trailing-exit ratchet, incomplete advanced order semantics, partial close-entry behavior.
- Bar Magnifier needs valid lower-timeframe bars; missing/invalid intrabar data warns or errors in strict mode and falls back to OHLC path.
- `request.security` supports deterministic child runtime evaluation but not nested requests unless explicitly enabled by config.
- Visual API is an event recorder, not a renderer. Tables/labels/lines/boxes have lifecycle coverage only.
- Reference-type history is unsupported.
- TA overload matrix is incomplete. Some helpers are batch-first or simplified and should be expanded only with fixtures.
- IO helpers target local CSV and optional Parquet; no remote data acquisition.

## Deferred for 1.0+

- Fixture-backed TradingView acceptance suites for priority strategies/indicators.
- Complete Pine visual namespace and rendering adapters.
- Full strategy tester parity matrix: trailing stops, risk/margin, order fill assumptions, tick/realtime behavior.
- Expanded TA overload/type matrix and source-compatible generated-code namespace aliases.
- Formal JSON schema files for reports and diagnostics.
