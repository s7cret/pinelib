# Current Limitations

Current release: v0.9.0 (`runtime_contract_v1.4` / `TZ_01`). See `docs/coverage_map_v0_9_0.md` for the full map.

- No fake TradingView parity. Missing features must stay explicit via diagnostics/errors.
- Realtime tick execution and full `calc_on_every_tick` semantics are not implemented.
- Strategy tester parity is partial: no margin calls/liquidation model, incomplete trailing exits, incomplete advanced order/fill assumption matrix.
- Bar Magnifier requires valid lower-timeframe data; otherwise it warns/falls back or errors in strict mode.
- `request.security` nested requests are unsupported unless config explicitly enables them.
- Visual support is a deterministic lifecycle event recorder, not a renderer.
- Reference-type history access is unsupported.
- TA overload matrix is incomplete; stateful runtime helpers require stable explicit `state_id`.
- IO helpers cover local CSV and optional Parquet only.
