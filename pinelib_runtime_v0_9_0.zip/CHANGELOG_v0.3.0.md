# PineLib Runtime v0.3.0

Release date: 2026-04-27
Runtime contract: 1.4

## Added

- Input registry and metadata for `input.int`, `input.float`, `input.bool`, `input.string`, `input.timeframe`, `input.symbol`, `input.session`, and `input.source` basics.
- Runtime validation for input min/max/options, timeframe syntax, session syntax, symbol/source defaults, with `PL_INPUT_VALIDATION_ERROR` diagnostics.
- Runtime metadata models for `syminfo`, enriched `timeframe`, and `barstate`.
- `RuntimeConfig.diagnostics` and diagnostic emission helper.
- DataProvider normalization metadata/logging in `InMemoryDataProvider`.
- `request.security` merge core for precomputed and callable requested values.
- `barmerge.gaps_on/off` and `barmerge.lookahead_on/off` merge semantics over validated chart/request bars.
- Callable `request.security` execution through child `PineRuntime` with isolated indicator state.
- Explicit nested request failure/diagnostic using `PL_UNSUPPORTED_NESTED_SECURITY` when nested security is disabled.
- DST-focused `TimeFunctions` coverage alongside regular and overnight session tests.

## Changed

- Package version bumped to `0.3.0` while keeping runtime contract version `1.4`.
- README now documents v0.3.0 runtime metadata, inputs, provider metadata, and request merge/execution foundation.
- Release archive/manifest build script now includes all versioned changelogs.

## Deferred

- Full TradingView parity/golden suite.
- Broker emulator and strategy recalculation schedule beyond existing foundations.
- Visual object lifecycle and reference object identity beyond v0.2/v0.3 foundations.
- Full `request.security` edge-case parity for every Pine barmerge nuance; current implementation is explicit foundation, not fake parity.
