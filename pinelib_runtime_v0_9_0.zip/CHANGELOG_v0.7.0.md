# PineLib Runtime v0.7.0

Released on the runtime_contract_v1.4 / TZ_01 track.

## Added

- Bar-by-bar `run_generated_strategy()` helper for generated-like strategy classes or callables.
- `StrategySchedule` and guarded `calc_on_order_fills` recalculation loop.
- `BacktestSnapshot`, `BacktestReport`, `BacktestResult`, JSON snapshot writing, and report schema metadata.
- Optimizer-friendly generated params / params metadata extraction into reports.
- Golden comparison utility with absolute/relative numeric tolerances.
- CSV OHLCV loader with aliases/validation and optional Parquet loader with graceful missing-dependency errors.
- Tests for generated-like strategy execution, runtime `process_orders_on_close`, guarded fill recalculation, CSV validation, compare tolerances, and report JSON schema.
- `docs/current_limitations.md` capturing present runtime/backtest limitations.

## Changed

- Bumped package version to `0.7.0` while retaining runtime contract version `1.4`.
- README now documents the generated strategy runner and bar file IO.

## Deferred / Known limits

- Parquet remains optional and depends on pandas plus a parquet engine.
- Backtest report metrics are current broker-emulator state snapshots, not a full TradingView Strategy Tester replica.
- Realtime tick execution, complete advanced order parity, and full golden TradingView parity suites remain future work.
