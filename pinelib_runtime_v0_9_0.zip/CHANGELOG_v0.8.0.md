# PineLib Runtime v0.8.0

Runtime contract: `1.4` / `TZ_01` track.

## Added

- TradingView parity fixture harness in `pinelib.parity`:
  - indicator CSV loader for exported columns
  - trades CSV loader
  - indicator column tolerance compare reports
  - strategy/equity tolerance compare reports and assertion helper
- AVAX/SOL/XLM target-strategy sample contract scaffolding with placeholder TradingView data paths.
- Official v0.8.0 namespace coverage map in `docs/coverage_map_v0_8_0.md`.
- Strategy broker diagnostics for accepted-but-not-emulated margin fields.
- Basic `close_entries_rule` FIFO/ANY close matching semantics.

## Changed

- Package version bumped to `0.8.0`.
- README updated with parity harness and coverage-map guidance.

## Deferred

- Stateful trailing-exit ratchet emulation remains diagnostic-only.
- Full TradingView Strategy Tester parity, realtime tick execution, margin calls/liquidation, and complete TA overload matrix remain deferred.
