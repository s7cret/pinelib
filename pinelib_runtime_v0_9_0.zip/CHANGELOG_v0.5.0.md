# PineLib Runtime v0.5.0

Release date: 2026-04-27
Contract: `runtime_contract_v1.4.md` / `TZ_01`

## Added

- Bar Magnifier foundation: `IntrabarDataProvider` is queried by the broker when `use_bar_magnifier=True`; intrabar bars are validated for chart-bar coverage and monotonic timestamps.
- Missing intrabar behavior: non-strict mode emits `PL_WARNING_BAR_MAGNIFIER_FALLBACK` and uses synthetic OHLC path; strict parity/diagnostics-as-errors raises `PL_MISSING_INTRABAR_DATA`.
- Fill source provenance: `Fill`, filled `Order`, and closed `Trade` records carry `fill_source` (`intrabar` or `ohlc_path`).
- Path-order execution arbitration so bracket TP/SL fills honor earliest crossing in the active OHLC/intrabar path instead of pending-order list order.
- `calc_on_every_tick` historical fallback diagnostic coverage via `PL_WARNING_CALC_ON_EVERY_TICK_FALLBACK`.
- Visual recorder foundation with stable `PineObjectId` for label/line/box/table creation, set/delete lifecycle events, active-object table, and count limits.
- Reference container foundation: `PineArray`, `PineMap`, and `PineMatrix` with reference identity and shallow copy semantics.
- Explicit reference history unsupported path: `reference_history()` emits/raises `PL_REFERENCE_HISTORY_UNSUPPORTED`.

## Tests

- Intrabar TP/SL ordering differing from synthetic OHLC path.
- Missing intrabar strict and non-strict fallback modes.
- Visual object lifecycle and limits.
- Array/map/matrix identity and copy behavior.
- Reference history unsupported diagnostic.

## Explicitly deferred

- Full TradingView Bar Magnifier lower-timeframe selection and golden fixture parity matrix.
- Realtime tick execution for `calc_on_every_tick`; historical mode remains close-pass with diagnostic.
- Full visual rendering/style API surface beyond deterministic recorder primitives.
- Complete Pine reference-type history semantics.
- Advanced broker features deferred in v0.4.0 (trailing exits, margin/liquidation edge cases, broader TV parity suite).
