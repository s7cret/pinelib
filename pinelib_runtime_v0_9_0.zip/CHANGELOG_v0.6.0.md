# PineLib Runtime v0.6.0

Release target: runtime_contract_v1.4 / TZ_01.

## Added

- Extended TA namespace coverage for common strategy dependencies:
  - bands/trend: `bb`, `bbw`, `supertrend`, `sar`
  - oscillators/direction: fast `stoch`, `dmi`, `adx`, `mfi`, `cci`, `obv`, `mom`, `roc`
  - averages/statistics: `wma`, `vwma`, `hma`, `swma`, `alma`, `linreg`, `variance`, `stdev`, `dev`, percentile/percentrank basics, `correlation`
  - series predicates/lookups: `valuewhen`, `barssince`, `rising`, `falling`, `pivot_high`, `pivot_low`
- Basic `pinelib.string` namespace helpers.
- Basic `pinelib.color` namespace with RGBA color records and common constants.
- Expanded `pinelib.math` helpers and constants.
- Tests covering supertrend direction sign, fast stoch semantics, bb/macd/dmi, valuewhen/barssince, and namespace helpers.

## Changed

- Package version bumped to `0.6.0`; runtime contract remains `1.4`.
- README and release manifest updated for v0.6.0 scope.

## Deferred / explicit limitations

- Several v0.6 TA additions are batch-first; unsupported scalar/runtime overloads raise `PineRuntimeError` rather than approximating hidden state.
- `ta.vwap()` supports batch cumulative VWAP; anchored/stateful runtime VWAP overloads remain deferred.
- Full TradingView overload parity and golden parity matrix remain future work.
