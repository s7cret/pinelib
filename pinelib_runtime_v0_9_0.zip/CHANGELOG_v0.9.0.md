# PineLib Runtime v0.9.0

Release-candidate hardening for `runtime_contract_v1.4` / `TZ_01`, focused on API stabilization before 1.0.

## Added

- Public API review (`docs/public_api_v0_9_0.md`) and semver policy (`docs/semantic_versioning_policy.md`).
- Exhaustive v0.9 coverage/limitations map and v0.8→v0.9 migration guide.
- `py.typed` marker for typed package consumers.
- GitHub Actions CI for Python 3.11-3.13: compile, pytest, mypy, release script smoke.
- Performance smoke benchmarks for runtime+TA and strategy broker loops.
- Edge tests for public exports, strategy stop-limit and ANY close-entry behavior, request merge failures/missing symbols, DST fall-back sessions, inputs, visual/reference lifecycle, and TA validation.

## Changed

- Package version bumped to `0.9.0`.
- Release builder now includes typed marker and CI workflow files in the archive/manifest.
- README updated to frame v0.9 as hardening/stabilization rather than broader parity.

## Compatibility

- v0.8 public imports should continue to work.
- Top-level `pinelib.__all__` is now treated as the reviewed public import surface for generated-code consumers.
- Invalid/unsupported behavior remains explicit via diagnostics/errors; no fake TradingView parity claims were added.

## Deferred

- Full TradingView strategy tester parity, realtime tick execution, full visual rendering API, complete TA overload matrix, complete reference history semantics, margin calls, and trailing-exit ratchets.
