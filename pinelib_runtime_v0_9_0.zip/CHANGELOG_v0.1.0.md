# Changelog v0.1.0

## Added

- `pinelib` package version `0.1.0`
- runtime contract constant `1.4`
- `Bar`, `Series`, `PineRuntime`, `RuntimeConfig`, `SymbolInfo`, `TimeframeInfo`, `TypeInfo`
- Pine `na` helpers and basic numeric/operator helpers
- `DataProvider` and validated `InMemoryDataProvider`
- timezone-aware `TimeFunctions` scaffold with regular and overnight session handling
- unit tests and release tooling

## Notes

- `request.security`, TA implementations, and strategy/broker execution are not part of v0.1.
- Reference history remains explicitly unsupported unless enabled by a future milestone.

