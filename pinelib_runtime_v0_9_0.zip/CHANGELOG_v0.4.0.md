# PineLib Runtime v0.4.0

Release date: 2026-04-27
Contract: `runtime_contract_v1.4.md`

## Added

- `pinelib.strategy` package with `StrategyContext`, declaration settings, order/fill/trade models.
- Strategy API MVP: `entry`, `order`, `exit`, `close`, `close_all`, `cancel`, `cancel_all`.
- Broker emulator basics: market, limit, stop, stop-limit, OHLC path fill ordering, open-gap fills, and `process_orders_on_close`.
- Position/equity state: position size, average price, open/net/gross profit, trade counters, open/closed trade logs.
- Sizing: fixed, cash, percent-of-equity.
- Commission/slippage support: percent, cash per order, cash per contract; price slippage adjustment.
- Pyramiding and entry reversal basics.
- `strategy.exit` bracket/OCA reduce foundation with reservation reduction diagnostic `PL_WARNING_EXIT_QTY_REDUCED`.
- Recalculation guard scaffold and fill-recalc pending flag for `calc_on_order_fills`.
- Unit coverage for market next-bar/open, process-on-close, limit/stop path and gap open fills, reversal/pyramiding, exit reservation, commission/slippage/sizing.

## Explicitly deferred

- Full Bar Magnifier execution and missing intrabar strict/fallback matrix.
- Trailing exits.
- Advanced margin/leverage liquidation model.
- Complete TradingView broker edge-case parity and golden fixture suite.
- Visual object recorder and full TA namespace beyond existing foundation.
