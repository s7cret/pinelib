# PineLib Runtime v0.2.0

Release date: 2026-04-27

## Added

- P0 TA namespace foundation with stateful runtime mode and batch mode for tests:
  - `ta.sma`, `ta.ema`, `ta.rma`, `ta.tr`, `ta.atr`, `ta.rsi`, `ta.macd`
  - `ta.highest`, `ta.lowest`, `ta.change`, `ta.cross`, `ta.crossover`, `ta.crossunder`
- Runtime `state_id` isolation checks for stateful TA helpers; reused IDs with incompatible
  helper state or changed lengths fail explicitly.
- `pinelib.math` Pine aliases: `pine_abs`, `pine_round`, `pine_min`, `pine_max`, `pine_sum`.
- `pinelib.core.precision` helpers: `pine_isclose`, `pine_eq`, `pine_ne`, `pine_gt`,
  `pine_gte`, `pine_lt`, `pine_lte`.
- Tests for warmup/`na` behavior, bool restrictions, runtime state isolation, TA edge cases,
  and batch/runtime consistency.

## Changed

- Package version bumped to `0.2.0`; runtime contract remains `1.4`.
- Public exports now include `ta`, math aliases, and precision helpers.
- Release builder now produces `pinelib_runtime_v0_2_0.zip` and `RELEASE_MANIFEST_v0_2_0.json`.

## Deferred / explicitly unsupported

- Full TradingView golden parity for every TA overload remains deferred until golden datasets are available.
- Advanced TA families (`supertrend`, `stoch`, DMI, bands, pivots, etc.), strategy broker
  emulator, visual objects, and complete `request.security` execution remain future milestones.
- Unsupported features must continue to fail explicitly rather than silently approximate TradingView behavior.
