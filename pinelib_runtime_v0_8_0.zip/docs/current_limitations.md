# Current PineLib Runtime Limitations

Status: v0.8.0, runtime contract v1.4 / TZ_01.

## Runtime and series

- Historical bar execution is supported; realtime tick semantics are not fully modeled.
- Reference-type history remains intentionally limited by `RuntimeConfig.reference_history_mode`.
- Some stateful helpers require explicit generated `state_id` ownership to avoid accidental state sharing.

## Strategy/backtest

- `run_generated_strategy()` is an integration runner for generated code, not a complete TradingView Strategy Tester clone.
- Broker emulator parity covers market/limit/stop/stop-limit basics, pyramiding, reversal sizing, exits, OCA-style bracket cancellation, `process_orders_on_close`, Bar Magnifier fallback/provenance, guarded `calc_on_order_fills` loops, and basic FIFO/ANY close matching.
- `calc_on_every_tick` emits a fallback diagnostic in historical mode.
- Advanced settings such as non-zero `backtest_fill_limits_assumption`, trailing-exit ratchets, margin/liquidation behavior, and full tester metrics are deferred. Margin fields are accepted and surfaced as diagnostics only.
- Backtest report fields are stable JSON-safe integration artifacts for downstream tooling and golden tests; additional metrics may be added in later schema versions.

## IO

- CSV loading requires UTC millisecond timestamps and strictly increasing bars.
- Parquet loading is optional. Without pandas and a parquet engine, `load_bars_parquet()` raises a clear `PineUnsupportedFeatureError`.
- Corporate actions, session repair, timezone conversion, and vendor-specific schema adapters are out of scope for v0.8.0.

## TA / namespaces

- Many TA helpers support batch mode first. Not every TradingView overload is implemented.
- Visual APIs record events but do not render chart objects.
- `request.security` remains conservative around nested requests unless explicitly enabled.
